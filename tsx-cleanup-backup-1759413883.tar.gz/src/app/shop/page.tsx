export default function ShopPage() {
  return (
    <div>
      <h1>Shop Page</h1>
    </div>
  );
}
